// 假设的后台接口URL（根据实际接口地址修改）
const apiEndpoint = 'http://your-api-url/ambulances'; // 你实际的API地址

// 登录按钮点击事件
document.getElementById('loginBtn').addEventListener('click', function() {
    alert('登录按钮被点击');
});

// 紧急求助按钮点击事件
document.getElementById('emergencyBtn').addEventListener('click', function() {
    alert('紧急求助按钮被点击');
});

// 救护车管理按钮点击事件
document.getElementById('ambulanceManagementBtn').addEventListener('click', function() {
    loadAmbulanceManagementPage();
});

// 加载救护车管理页面
function loadAmbulanceManagementPage() {
    const contentArea = document.getElementById('ambulanceManagementContent');
    contentArea.innerHTML = `
        <div class="filter-container">
            <div class="filter">
                <select id="statusFilter">
                    <option value="">选择车辆状态</option>
                    <option value="执行任务中">执行任务中</option>
                    <option value="待班中">待班中</option>
                    <option value="维修中">维修中</option>
                </select>
            </div>
            <div class="filter">
                <input type="text" id="licensePlateFilter" placeholder="输入车牌号">
            </div>
            <button class="btn-filter" id="filterBtn">筛选</button>
        </div>
        <table class="table-container" id="ambulanceTable">
            <thead>
                <tr>
                    <th>车牌号</th>
                    <th>车辆状态</th>
                </tr>
            </thead>
            <tbody>
                <!-- 动态内容填充 -->
            </tbody>
        </table>
    `;

    // 为筛选按钮添加事件
    document.getElementById('filterBtn').addEventListener('click', applyFilters);

    // 加载救护车数据
    fetchAmbulanceData();
}

// 获取救护车数据
function fetchAmbulanceData() {
    // 获取筛选条件
    const statusFilter = document.getElementById('statusFilter').value;
    const licensePlateFilter = document.getElementById('licensePlateFilter').value.trim();

    // 构造请求参数
    const params = new URLSearchParams();
    if (statusFilter) params.append('status', statusFilter);
    if (licensePlateFilter) params.append('licensePlate', licensePlateFilter);

    // 创建请求 URL
    const url = `${apiEndpoint}?${params.toString()}`;

    // 使用 fetch API 请求后台数据
    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                displayAmbulances(data.data); // 数据返回成功，渲染列表
            } else {
                alert('数据加载失败');
            }
        })
        .catch(error => {
            console.error('Error fetching data:', error);
            alert('请求失败，请稍后再试');
        });
}

// 显示救护车数据
function displayAmbulances(ambulances) {
    const tableBody = document.getElementById('ambulanceTable').getElementsByTagName('tbody')[0];
    tableBody.innerHTML = '';

    ambulances.forEach(ambulance => {
        const row = tableBody.insertRow();
        const licensePlateCell = row.insertCell(0);
        const statusCell = row.insertCell(1);
        licensePlateCell.textContent = ambulance.licensePlate;
        statusCell.textContent = ambulance.status;
    });
}

// 根据筛选条件应用筛选
function applyFilters() {
    fetchAmbulanceData();  // 重新获取数据并根据筛选条件渲染
}
